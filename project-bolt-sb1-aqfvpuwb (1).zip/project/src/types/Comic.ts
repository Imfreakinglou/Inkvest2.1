export enum ComicCondition {
  Poor = 'P',
  Fair = 'FR',
  Good = 'G',
  VeryGood = 'VG',
  Fine = 'FN',
  VeryFine = 'VF',
  NearMint = 'NM',
  Mint = 'M',
}

export type GradingCompany = 'CGC' | 'CBCS' | 'PGX';

export interface Comic {
  id: string;
  title: string;
  issueNumber: string;
  year?: number;
  volume?: number;
  publisher?: string;
  isSlabbed: boolean;
  gradingCompany?: GradingCompany;
  grade?: number;
  condition?: ComicCondition;
  purchasePrice?: number;
  purchaseDate?: string;
  currentValue?: number;
  estimatedValue?: number;
  lastUpdated?: string;
  addedDate: string;
  notes?: string;
  isSigned?: boolean;
  upc?: string;
  coverImage?: string;
  mediaRelated?: boolean;
  keyIssue?: boolean;
  keyDetails?: string;
}