export interface PortfolioBreakdown {
  name: string;
  value: number;
}

export interface GrowthDataPoint {
  date: string;
  value: number;
}

export interface TopPerformer {
  id: string;
  title: string;
  issueNumber: string;
  gain: number;
  gainPercentage: number;
}

export interface Portfolio {
  totalValue: number;
  totalCost: number;
  potentialValue: number;
  totalComics: number;
  growthRate: number;
  publisherBreakdown: PortfolioBreakdown[];
  growthHistory: GrowthDataPoint[];
  topPerformer?: TopPerformer;
}