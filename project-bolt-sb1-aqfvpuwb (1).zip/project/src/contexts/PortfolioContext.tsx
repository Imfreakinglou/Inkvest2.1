import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { Comic } from '../types/Comic';
import { Portfolio } from '../types/Portfolio';
import { useAuth } from './AuthContext';
import { toast } from 'react-toastify';

interface PortfolioContextType {
  portfolio: Portfolio;
  comics: Comic[];
  loading: boolean;
  addComic: (comic: Comic) => Promise<void>;
  updateComic: (id: string, comic: Partial<Comic>) => Promise<void>;
  removeComic: (id: string) => Promise<void>;
  refreshPortfolio: () => Promise<void>;
  getComicById: (id: string) => Comic | undefined;
}

const defaultPortfolio: Portfolio = {
  totalValue: 0,
  totalCost: 0,
  potentialValue: 0,
  totalComics: 0,
  growthRate: 0,
  publisherBreakdown: [],
  growthHistory: [],
};

const PortfolioContext = createContext<PortfolioContextType>({
  portfolio: defaultPortfolio,
  comics: [],
  loading: false,
  addComic: async () => {},
  updateComic: async () => {},
  removeComic: async () => {},
  refreshPortfolio: async () => {},
  getComicById: () => undefined,
});

export const usePortfolio = () => useContext(PortfolioContext);

export const PortfolioProvider: React.FC<{children: React.ReactNode}> = ({ children }) => {
  const [portfolio, setPortfolio] = useState<Portfolio>(defaultPortfolio);
  const [comics, setComics] = useState<Comic[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const { user } = useAuth();
  
  // Initialize from local storage on mount
  useEffect(() => {
    if (user) {
      loadPortfolio();
    } else {
      setPortfolio(defaultPortfolio);
      setComics([]);
      setLoading(false);
    }
  }, [user]);
  
  // Load portfolio data
  const loadPortfolio = useCallback(async () => {
    setLoading(true);
    try {
      // In a real app, this would fetch from an API
      // For demo, we'll use localStorage
      const savedComics = localStorage.getItem('comics');
      if (savedComics) {
        const parsedComics = JSON.parse(savedComics) as Comic[];
        setComics(parsedComics);
        calculatePortfolioStats(parsedComics);
      }
    } catch (error) {
      console.error('Failed to load portfolio:', error);
      toast.error('Failed to load your portfolio');
    } finally {
      setLoading(false);
    }
  }, [user]);
  
  // Calculate portfolio statistics based on comics
  const calculatePortfolioStats = (comicsList: Comic[]) => {
    if (!comicsList.length) {
      setPortfolio(defaultPortfolio);
      return;
    }
    
    const totalValue = comicsList.reduce((sum, comic) => sum + (comic.currentValue || 0), 0);
    const totalCost = comicsList.reduce((sum, comic) => sum + (comic.purchasePrice || 0), 0);
    const potentialValue = comicsList.reduce((sum, comic) => sum + (comic.estimatedValue || 0), 0);
    
    // Calculate publisher breakdown
    const publishers = comicsList.reduce((acc, comic) => {
      const publisher = comic.publisher || 'Unknown';
      if (!acc[publisher]) {
        acc[publisher] = 0;
      }
      acc[publisher] += comic.currentValue || 0;
      return acc;
    }, {} as Record<string, number>);
    
    const publisherBreakdown = Object.entries(publishers).map(([name, value]) => ({
      name,
      value
    }));
    
    // Calculate growth rate
    const growthRate = totalCost > 0 
      ? ((totalValue - totalCost) / totalCost) * 100 
      : 0;
    
    // Mock growth history data (in a real app, this would come from the backend)
    const today = new Date();
    const growthHistory = Array.from({ length: 6 }, (_, i) => {
      const date = new Date();
      date.setMonth(today.getMonth() - 5 + i);
      
      // Generate some plausible data with an upward trend
      const baseValue = totalValue * 0.7;
      const growth = Math.random() * 0.05 + 0.02; // 2-7% growth per month
      const value = baseValue * Math.pow(1 + growth, i);
      
      return {
        date: date.toISOString().substring(0, 7), // YYYY-MM format
        value: Math.round(value)
      };
    });
    
    // Find top performer
    let topPerformer = null;
    if (comicsList.length > 0) {
      const comicsWithGains = comicsList
        .filter(comic => comic.purchasePrice && comic.currentValue)
        .map(comic => ({
          ...comic,
          gain: (comic.currentValue || 0) - (comic.purchasePrice || 0),
          gainPercentage: comic.purchasePrice 
            ? Math.round(((comic.currentValue || 0) - comic.purchasePrice) / comic.purchasePrice * 100) 
            : 0
        }))
        .sort((a, b) => b.gainPercentage - a.gainPercentage);
      
      if (comicsWithGains.length > 0) {
        topPerformer = comicsWithGains[0];
      }
    }
    
    setPortfolio({
      totalValue,
      totalCost,
      potentialValue,
      totalComics: comicsList.length,
      growthRate,
      publisherBreakdown,
      growthHistory,
      topPerformer
    });
  };
  
  // Add a new comic to the collection
  const addComic = async (comic: Comic) => {
    try {
      // Generate a unique ID
      const newComic = {
        ...comic,
        id: Date.now().toString(),
        addedDate: new Date().toISOString()
      };
      
      const updatedComics = [...comics, newComic];
      setComics(updatedComics);
      calculatePortfolioStats(updatedComics);
      
      // Save to localStorage (in a real app, this would be an API call)
      localStorage.setItem('comics', JSON.stringify(updatedComics));
      
      toast.success('Comic added to your collection!');
      return newComic;
    } catch (error) {
      console.error('Failed to add comic:', error);
      toast.error('Failed to add comic');
      throw error;
    }
  };
  
  // Update an existing comic
  const updateComic = async (id: string, updates: Partial<Comic>) => {
    try {
      const index = comics.findIndex(c => c.id === id);
      if (index === -1) {
        throw new Error('Comic not found');
      }
      
      const updatedComics = [...comics];
      updatedComics[index] = { ...updatedComics[index], ...updates };
      
      setComics(updatedComics);
      calculatePortfolioStats(updatedComics);
      
      // Save to localStorage
      localStorage.setItem('comics', JSON.stringify(updatedComics));
      
      toast.success('Comic updated successfully');
    } catch (error) {
      console.error('Failed to update comic:', error);
      toast.error('Failed to update comic');
      throw error;
    }
  };
  
  // Remove a comic from the collection
  const removeComic = async (id: string) => {
    try {
      const updatedComics = comics.filter(comic => comic.id !== id);
      setComics(updatedComics);
      calculatePortfolioStats(updatedComics);
      
      // Save to localStorage
      localStorage.setItem('comics', JSON.stringify(updatedComics));
      
      toast.success('Comic removed from your collection');
    } catch (error) {
      console.error('Failed to remove comic:', error);
      toast.error('Failed to remove comic');
      throw error;
    }
  };
  
  // Refresh portfolio data
  const refreshPortfolio = async () => {
    return loadPortfolio();
  };
  
  // Get a specific comic by ID
  const getComicById = (id: string) => {
    return comics.find(comic => comic.id === id);
  };
  
  const value = {
    portfolio,
    comics,
    loading,
    addComic,
    updateComic,
    removeComic,
    refreshPortfolio,
    getComicById,
  };
  
  return (
    <PortfolioContext.Provider value={value}>
      {children}
    </PortfolioContext.Provider>
  );
};