import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

// Context providers
import { PortfolioProvider } from './contexts/PortfolioContext';
import { AuthProvider } from './contexts/AuthContext';

// Pages
import HomePage from './pages/HomePage';
import ScanPage from './pages/ScanPage';
import CollectionPage from './pages/CollectionPage';
import ComicDetailPage from './pages/ComicDetailPage';
import RecommendationsPage from './pages/RecommendationsPage';
import OnboardingPage from './pages/OnboardingPage';
import LoginPage from './pages/LoginPage';
import SettingsPage from './pages/SettingsPage';

// Components
import Navigation from './components/Navigation';
import ProtectedRoute from './components/ProtectedRoute';

// Styles
import './styles/index.css';

function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <PortfolioProvider>
          <div className="app-container">
            <ToastContainer position="top-center" autoClose={3000} />
            <Routes>
              <Route path="/login" element={<LoginPage />} />
              <Route path="/onboarding" element={<OnboardingPage />} />
              <Route path="/" element={
                <ProtectedRoute>
                  <Navigation />
                  <HomePage />
                </ProtectedRoute>
              } />
              <Route path="/scan" element={
                <ProtectedRoute>
                  <Navigation />
                  <ScanPage />
                </ProtectedRoute>
              } />
              <Route path="/collection" element={
                <ProtectedRoute>
                  <Navigation />
                  <CollectionPage />
                </ProtectedRoute>
              } />
              <Route path="/comic/:id" element={
                <ProtectedRoute>
                  <Navigation />
                  <ComicDetailPage />
                </ProtectedRoute>
              } />
              <Route path="/recommendations" element={
                <ProtectedRoute>
                  <Navigation />
                  <RecommendationsPage />
                </ProtectedRoute>
              } />
              <Route path="/settings" element={
                <ProtectedRoute>
                  <Navigation />
                  <SettingsPage />
                </ProtectedRoute>
              } />
            </Routes>
          </div>
        </PortfolioProvider>
      </AuthProvider>
    </BrowserRouter>
  );
}

export default App;