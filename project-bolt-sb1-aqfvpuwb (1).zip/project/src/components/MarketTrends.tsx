import React from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import '../styles/MarketTrends.css';

// Sample market trend data
const marketTrendData = [
  {
    name: 'Spider-Man',
    value: 35,
    color: '#D32F2F'
  },
  {
    name: 'X-Men',
    value: 28,
    color: '#1976D2'
  },
  {
    name: 'Batman',
    value: 22,
    color: '#212121'
  },
  {
    name: 'Independent',
    value: 18,
    color: '#FFA000'
  },
  {
    name: 'Horror',
    value: 12,
    color: '#7B1FA2'
  }
];

// Sample hot comics this week
const hotComics = [
  {
    title: 'Something is Killing the Children #1',
    reason: 'Netflix adaptation announced',
    change: '+15%'
  },
  {
    title: 'Deadpool #1 (2023)',
    reason: 'Deadpool 3 trailer released',
    change: '+22%'
  },
  {
    title: 'Ultimate Fallout #4',
    reason: 'Miles Morales in new Spider-Verse film',
    change: '+8%'
  }
];

const MarketTrends: React.FC = () => {
  return (
    <div className="market-trends-container">
      <div className="market-chart">
        <h3>Hot Categories (% Growth)</h3>
        <ResponsiveContainer width="100%" height={200}>
          <BarChart data={marketTrendData} margin={{ top: 5, right: 5, bottom: 20, left: 0 }}>
            <XAxis dataKey="name" tick={{ fontSize: 12 }} />
            <YAxis hide={true} />
            <Tooltip 
              formatter={(value) => [`${value}%`, 'Growth']}
              cursor={{ fill: 'rgba(0,0,0,0.05)' }}
            />
            <Bar dataKey="value" radius={[4, 4, 0, 0]}>
              {marketTrendData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
      
      <div className="hot-comics">
        <h3>Hot Comics This Week</h3>
        <ul className="hot-comics-list">
          {hotComics.map((comic, index) => (
            <li key={index} className="hot-comic-item">
              <div className="hot-comic-info">
                <h4 className="hot-comic-title">{comic.title}</h4>
                <p className="hot-comic-reason">{comic.reason}</p>
              </div>
              <span className="hot-comic-change">{comic.change}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default MarketTrends;