import React, { useState } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { 
  Home, 
  Scan, 
  BarChart3, 
  BookOpen, 
  Settings, 
  Menu, 
  X 
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import '../styles/Navigation.css';

const Navigation: React.FC = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const location = useLocation();
  const { user, logout } = useAuth();
  
  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };
  
  const closeMobileMenu = () => {
    setMobileMenuOpen(false);
  };
  
  const isActive = (path: string) => {
    return location.pathname === path;
  };
  
  return (
    <>
      <nav className={`app-navigation ${mobileMenuOpen ? 'menu-open' : ''}`}>
        <div className="nav-brand">
          <span className="logo">InkVest</span>
          <button className="mobile-menu-toggle" onClick={toggleMobileMenu}>
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
        
        <ul className="nav-items">
          <li>
            <NavLink 
              to="/" 
              className={isActive('/') ? 'active' : ''}
              onClick={closeMobileMenu}
            >
              <Home size={20} />
              <span>Dashboard</span>
            </NavLink>
          </li>
          <li>
            <NavLink 
              to="/scan" 
              className={isActive('/scan') ? 'active' : ''}
              onClick={closeMobileMenu}
            >
              <Scan size={20} />
              <span>Scan</span>
            </NavLink>
          </li>
          <li>
            <NavLink 
              to="/collection" 
              className={isActive('/collection') ? 'active' : ''}
              onClick={closeMobileMenu}
            >
              <BookOpen size={20} />
              <span>Collection</span>
            </NavLink>
          </li>
          <li>
            <NavLink 
              to="/recommendations" 
              className={isActive('/recommendations') ? 'active' : ''}
              onClick={closeMobileMenu}
            >
              <BarChart3 size={20} />
              <span>Insights</span>
            </NavLink>
          </li>
          <li>
            <NavLink 
              to="/settings" 
              className={isActive('/settings') ? 'active' : ''}
              onClick={closeMobileMenu}
            >
              <Settings size={20} />
              <span>Settings</span>
            </NavLink>
          </li>
        </ul>
        
        {user && (
          <div className="user-profile">
            <div className="avatar">
              {user.displayName ? user.displayName.charAt(0).toUpperCase() : 'U'}
            </div>
            <div className="user-info">
              <span className="user-name">{user.displayName || 'User'}</span>
              <button className="logout-button" onClick={logout}>
                Log out
              </button>
            </div>
          </div>
        )}
      </nav>
      
      {mobileMenuOpen && (
        <div className="mobile-menu-backdrop" onClick={closeMobileMenu}></div>
      )}
    </>
  );
};

export default Navigation;