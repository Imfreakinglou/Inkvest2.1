import React from 'react';
import { useNavigate } from 'react-router-dom';
import { usePortfolio } from '../contexts/PortfolioContext';
import ComicCard from './ComicCard';
import '../styles/RecentComics.css';

interface RecentComicsProps {
  limit?: number;
}

const RecentComics: React.FC<RecentComicsProps> = ({ limit = 3 }) => {
  const { comics } = usePortfolio();
  const navigate = useNavigate();
  
  // Sort by added date and take the most recent
  const recentComics = [...comics]
    .sort((a, b) => {
      const dateA = new Date(a.addedDate || '');
      const dateB = new Date(b.addedDate || '');
      return dateB.getTime() - dateA.getTime();
    })
    .slice(0, limit);
  
  const handleComicClick = (id: string) => {
    navigate(`/comic/${id}`);
  };
  
  if (recentComics.length === 0) {
    return (
      <div className="no-recent-comics">
        <p>No comics in your collection yet</p>
        <button 
          className="button secondary"
          onClick={() => navigate('/scan')}
        >
          Add Your First Comic
        </button>
      </div>
    );
  }
  
  return (
    <div className="recent-comics">
      {recentComics.map(comic => (
        <ComicCard 
          key={comic.id} 
          comic={comic} 
          onClick={() => handleComicClick(comic.id)}
        />
      ))}
      
      {comics.length > limit && (
        <button 
          className="view-all-button"
          onClick={() => navigate('/collection')}
        >
          View All Comics
        </button>
      )}
    </div>
  );
};

export default RecentComics;