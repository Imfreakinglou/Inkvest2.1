import React, { useState } from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip } from 'recharts';
import { TrendingUp, TrendingDown, Zap, DollarSign, AlertCircle, Info } from 'lucide-react';
import { Portfolio } from '../types/Portfolio';
import '../styles/PortfolioSummary.css';

interface PortfolioSummaryProps {
  portfolio: Portfolio;
}

const COLORS = ['#1976D2', '#D32F2F', '#388E3C', '#FFA000', '#7B1FA2', '#0097A7'];

// Display modes for the main chart
enum ChartMode {
  Value = 'value',
  Growth = 'growth',
  Publishers = 'publishers'
}

const PortfolioSummary: React.FC<PortfolioSummaryProps> = ({ portfolio }) => {
  const [chartMode, setChartMode] = useState<ChartMode>(ChartMode.Value);
  
  // Format currency values
  const formatCurrency = (value: number): string => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };
  
  // Determine if the portfolio is growing or shrinking
  const isGrowing = portfolio.totalValue > portfolio.totalCost;
  const growthPercentage = portfolio.totalCost > 0 
    ? ((portfolio.totalValue - portfolio.totalCost) / portfolio.totalCost * 100).toFixed(1)
    : '0.0';
  
  // Prepare chart data based on mode
  const getChartData = () => {
    switch(chartMode) {
      case ChartMode.Publishers:
        return portfolio.publisherBreakdown || [];
      case ChartMode.Growth:
        return portfolio.growthHistory || [];
      case ChartMode.Value:
      default:
        return [
          { name: 'Current Value', value: portfolio.totalValue },
          { name: 'Total Cost', value: portfolio.totalCost }
        ];
    }
  };
  
  // Render different charts based on mode
  const renderChart = () => {
    const data = getChartData();
    
    if (chartMode === ChartMode.Growth) {
      return (
        <ResponsiveContainer width="100%" height={200}>
          <LineChart data={data}>
            <XAxis dataKey="date" />
            <YAxis />
            <Tooltip formatter={(value) => formatCurrency(Number(value))} />
            <Line 
              type="monotone" 
              dataKey="value" 
              stroke="#1976D2" 
              strokeWidth={2} 
              dot={false} 
            />
          </LineChart>
        </ResponsiveContainer>
      );
    }
    
    return (
      <ResponsiveContainer width="100%" height={200}>
        <PieChart>
          <Pie
            data={data}
            cx="50%"
            cy="50%"
            innerRadius={60}
            outerRadius={80}
            paddingAngle={2}
            dataKey="value"
            labelLine={false}
            label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
          >
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
            ))}
          </Pie>
          <Tooltip formatter={(value) => formatCurrency(Number(value))} />
        </PieChart>
      </ResponsiveContainer>
    );
  };
  
  if (!portfolio) {
    return (
      <div className="portfolio-summary empty">
        <AlertCircle size={48} />
        <p>Portfolio data not available</p>
      </div>
    );
  }
  
  if (portfolio.totalComics === 0) {
    return (
      <div className="portfolio-summary empty">
        <Info size={48} />
        <h3>Your Portfolio is Empty</h3>
        <p>Add comics to start tracking your collection's value</p>
      </div>
    );
  }
  
  return (
    <div className="portfolio-summary">
      <div className="summary-header">
        <div className="portfolio-value">
          <h2>{formatCurrency(portfolio.totalValue)}</h2>
          <div className={`growth-indicator ${isGrowing ? 'positive' : 'negative'}`}>
            {isGrowing ? <TrendingUp size={18} /> : <TrendingDown size={18} />}
            <span>{growthPercentage}%</span>
          </div>
        </div>
        
        <div className="chart-mode-selector">
          <button 
            className={chartMode === ChartMode.Value ? 'active' : ''}
            onClick={() => setChartMode(ChartMode.Value)}
          >
            Value
          </button>
          <button 
            className={chartMode === ChartMode.Growth ? 'active' : ''}
            onClick={() => setChartMode(ChartMode.Growth)}
          >
            History
          </button>
          <button 
            className={chartMode === ChartMode.Publishers ? 'active' : ''}
            onClick={() => setChartMode(ChartMode.Publishers)}
          >
            Publishers
          </button>
        </div>
      </div>
      
      <div className="chart-container">
        {renderChart()}
      </div>
      
      <div className="portfolio-stats">
        <div className="stat-item">
          <DollarSign size={18} />
          <div className="stat-content">
            <span className="stat-label">Total Cost</span>
            <span className="stat-value">{formatCurrency(portfolio.totalCost)}</span>
          </div>
        </div>
        
        <div className="stat-item">
          <Zap size={18} />
          <div className="stat-content">
            <span className="stat-label">Potential (2030)</span>
            <span className="stat-value">{formatCurrency(portfolio.potentialValue)}</span>
          </div>
        </div>
        
        <div className="stat-item">
          <div className="stat-content">
            <span className="stat-label">Comics</span>
            <span className="stat-value">{portfolio.totalComics}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PortfolioSummary;