import React, { ReactNode } from 'react';
import '../styles/ActionButton.css';

interface ActionButtonProps {
  icon: ReactNode;
  label: string;
  onClick: () => void;
  primary?: boolean;
}

const ActionButton: React.FC<ActionButtonProps> = ({ 
  icon, 
  label, 
  onClick, 
  primary = false 
}) => {
  return (
    <button 
      className={`action-button ${primary ? 'primary' : 'secondary'}`} 
      onClick={onClick}
    >
      <div className="button-icon">
        {icon}
      </div>
      <span className="button-label">{label}</span>
    </button>
  );
};

export default ActionButton;