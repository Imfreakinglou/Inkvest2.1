import React from 'react';
import { TrendingUp, TrendingDown, AlertCircle, Award } from 'lucide-react';
import { Comic } from '../types/Comic';
import '../styles/ComicCard.css';

interface ComicCardProps {
  comic: Comic;
  onClick: () => void;
}

const ComicCard: React.FC<ComicCardProps> = ({ comic, onClick }) => {
  const { 
    title, 
    issueNumber, 
    year, 
    publisher, 
    currentValue, 
    purchasePrice,
    isSlabbed,
    grade,
    condition,
    keyIssue
  } = comic;
  
  // Calculate gain/loss
  const hasGain = purchasePrice !== undefined && currentValue !== undefined;
  const gainAmount = hasGain ? currentValue - purchasePrice : 0;
  const gainPercent = hasGain && purchasePrice > 0 
    ? Math.round((gainAmount / purchasePrice) * 100) 
    : 0;
  const isPositiveGain = gainAmount > 0;
  
  // Determine image URL
  // In a real app, this would use the comic's actual image
  // For demo, we'll use a placeholder based on the publisher
  const getPlaceholderImage = () => {
    if (publisher?.toLowerCase().includes('marvel')) {
      return 'https://images.pexels.com/photos/7800653/pexels-photo-7800653.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2';
    } else if (publisher?.toLowerCase().includes('dc')) {
      return 'https://images.pexels.com/photos/8310426/pexels-photo-8310426.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2';
    } else if (publisher?.toLowerCase().includes('image')) {
      return 'https://images.pexels.com/photos/7115878/pexels-photo-7115878.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2';
    } else {
      return 'https://images.pexels.com/photos/6474343/pexels-photo-6474343.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2';
    }
  };
  
  return (
    <div className="comic-card" onClick={onClick}>
      <div className="comic-image-container">
        <img 
          src={comic.coverImage || getPlaceholderImage()} 
          alt={`${title} #${issueNumber}`} 
          className="comic-image"
        />
        
        {keyIssue && (
          <div className="key-issue-badge">
            <Award size={16} />
            <span>Key Issue</span>
          </div>
        )}
      </div>
      
      <div className="comic-details">
        <h3 className="comic-title">
          {title} #{issueNumber}
        </h3>
        
        <div className="comic-subtitle">
          {publisher && <span className="publisher">{publisher}</span>}
          {year && <span className="year">{year}</span>}
        </div>
        
        <div className="grade-info">
          {isSlabbed ? (
            <span className="slabbed-grade">{comic.gradingCompany} {grade}</span>
          ) : (
            condition && <span className="raw-condition">{condition}</span>
          )}
        </div>
        
        <div className="comic-value">
          <span className="current-value">${currentValue?.toFixed(2) || '0.00'}</span>
          
          {hasGain && (
            <div className={`value-change ${isPositiveGain ? 'positive' : 'negative'}`}>
              {isPositiveGain ? (
                <TrendingUp size={16} />
              ) : (
                <TrendingDown size={16} />
              )}
              <span>{isPositiveGain ? '+' : ''}{gainPercent}%</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ComicCard;