import React, { useState, useEffect } from 'react';
import { Search, AlertCircle } from 'lucide-react';
import { Comic, ComicCondition, GradingCompany } from '../types/Comic';
import { useValuationService } from '../hooks/useValuationService';
import '../styles/ComicDetailForm.css';

interface ComicDetailFormProps {
  initialData?: Partial<Comic>;
  onChange: (data: Partial<Comic>) => void;
}

const ComicDetailForm: React.FC<ComicDetailFormProps> = ({ 
  initialData = {}, 
  onChange 
}) => {
  const [formData, setFormData] = useState<Partial<Comic>>(initialData);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const { getEstimatedValue, isLoading } = useValuationService();
  
  useEffect(() => {
    setFormData(initialData);
  }, [initialData]);
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    
    // Clear error when field is modified
    if (errors[name]) {
      setErrors(prev => {
        const updated = {...prev};
        delete updated[name];
        return updated;
      });
    }
    
    const updatedData = { ...formData, [name]: value };
    setFormData(updatedData);
    onChange(updatedData);
  };
  
  const handleGradingChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const { value } = e.target;
    const isSlabbed = value !== 'raw';
    
    let updates: Partial<Comic> = { 
      isSlabbed,
      gradingCompany: isSlabbed ? value as GradingCompany : undefined
    };
    
    const updatedData = { ...formData, ...updates };
    setFormData(updatedData);
    onChange(updatedData);
  };
  
  const handleLookupValue = async () => {
    if (!formData.title || !formData.issueNumber) {
      setErrors({
        ...errors,
        title: !formData.title ? 'Title is required' : '',
        issueNumber: !formData.issueNumber ? 'Issue number is required' : ''
      });
      return;
    }
    
    try {
      const valueData = await getEstimatedValue(formData);
      const updatedData = { 
        ...formData, 
        currentValue: valueData.currentValue,
        estimatedValue: valueData.estimatedValue,
        lastUpdated: new Date().toISOString()
      };
      setFormData(updatedData);
      onChange(updatedData);
    } catch (error) {
      console.error('Failed to get value estimate:', error);
    }
  };
  
  return (
    <div className="comic-detail-form">
      <div className="form-group">
        <label htmlFor="title">Title *</label>
        <input
          type="text"
          id="title"
          name="title"
          value={formData.title || ''}
          onChange={handleChange}
          placeholder="e.g. Amazing Spider-Man"
          className={errors.title ? 'error' : ''}
        />
        {errors.title && (
          <div className="error-message">
            <AlertCircle size={16} />
            <span>{errors.title}</span>
          </div>
        )}
      </div>
      
      <div className="form-row">
        <div className="form-group">
          <label htmlFor="issueNumber">Issue Number *</label>
          <input
            type="text"
            id="issueNumber"
            name="issueNumber"
            value={formData.issueNumber || ''}
            onChange={handleChange}
            placeholder="e.g. 300"
            className={errors.issueNumber ? 'error' : ''}
          />
          {errors.issueNumber && (
            <div className="error-message">
              <AlertCircle size={16} />
              <span>{errors.issueNumber}</span>
            </div>
          )}
        </div>
        
        <div className="form-group">
          <label htmlFor="year">Year</label>
          <input
            type="number"
            id="year"
            name="year"
            value={formData.year || ''}
            onChange={handleChange}
            placeholder="e.g. 1993"
          />
        </div>
      </div>
      
      <div className="form-group">
        <label htmlFor="publisher">Publisher</label>
        <input
          type="text"
          id="publisher"
          name="publisher"
          value={formData.publisher || ''}
          onChange={handleChange}
          placeholder="e.g. Marvel"
        />
      </div>
      
      <div className="form-group">
        <label htmlFor="gradingStatus">Grading Status</label>
        <select
          id="gradingStatus"
          name="gradingStatus"
          value={formData.isSlabbed ? formData.gradingCompany : 'raw'}
          onChange={handleGradingChange}
        >
          <option value="raw">Raw (Not Graded)</option>
          <option value="CGC">CGC</option>
          <option value="CBCS">CBCS</option>
          <option value="PGX">PGX</option>
        </select>
      </div>
      
      {formData.isSlabbed ? (
        <div className="form-group">
          <label htmlFor="grade">Grade</label>
          <input
            type="number"
            id="grade"
            name="grade"
            min="0.5"
            max="10"
            step="0.1"
            value={formData.grade || ''}
            onChange={handleChange}
            placeholder="e.g. 9.8"
          />
          <div className="grade-slider">
            <input
              type="range"
              min="0.5"
              max="10"
              step="0.1"
              value={formData.grade || 9.0}
              onChange={(e) => {
                const grade = parseFloat(e.target.value);
                setFormData({...formData, grade});
                onChange({...formData, grade});
              }}
            />
            <div className="grade-marks">
              <span>0.5</span>
              <span>5.0</span>
              <span>10.0</span>
            </div>
          </div>
        </div>
      ) : (
        <div className="form-group">
          <label htmlFor="condition">Condition</label>
          <select
            id="condition"
            name="condition"
            value={formData.condition || ''}
            onChange={handleChange}
          >
            <option value="">Select Condition</option>
            <option value={ComicCondition.Poor}>Poor (P)</option>
            <option value={ComicCondition.Fair}>Fair (FR)</option>
            <option value={ComicCondition.Good}>Good (G)</option>
            <option value={ComicCondition.VeryGood}>Very Good (VG)</option>
            <option value={ComicCondition.Fine}>Fine (F)</option>
            <option value={ComicCondition.VeryFine}>Very Fine (VF)</option>
            <option value={ComicCondition.NearMint}>Near Mint (NM)</option>
            <option value={ComicCondition.Mint}>Mint (M)</option>
          </select>
        </div>
      )}
      
      <div className="form-group">
        <label htmlFor="purchasePrice">Purchase Price ($)</label>
        <input
          type="number"
          id="purchasePrice"
          name="purchasePrice"
          value={formData.purchasePrice || ''}
          onChange={handleChange}
          placeholder="e.g. 25.00"
          step="0.01"
        />
      </div>
      
      <div className="form-group">
        <label htmlFor="purchaseDate">Purchase Date</label>
        <input
          type="date"
          id="purchaseDate"
          name="purchaseDate"
          value={formData.purchaseDate || ''}
          onChange={handleChange}
        />
      </div>
      
      <div className="value-lookup">
        <div className="value-fields">
          <div className="form-group">
            <label>Current Estimated Value</label>
            <div className="value-display">
              ${formData.currentValue?.toFixed(2) || '0.00'}
            </div>
          </div>
          <div className="form-group">
            <label>Future Potential Value (2030)</label>
            <div className="value-display future">
              ${formData.estimatedValue?.toFixed(2) || '0.00'}
            </div>
          </div>
        </div>
        <button 
          type="button" 
          className="lookup-button"
          onClick={handleLookupValue}
          disabled={isLoading}
        >
          {isLoading ? 'Loading...' : (
            <>
              <Search size={16} />
              Lookup Value
            </>
          )}
        </button>
      </div>
      
      <div className="form-group">
        <label htmlFor="notes">Notes</label>
        <textarea
          id="notes"
          name="notes"
          value={formData.notes || ''}
          onChange={handleChange}
          placeholder="E.g., First appearance of character, signed by artist, variant cover, etc."
          rows={3}
        />
      </div>
    </div>
  );
};

export default ComicDetailForm;