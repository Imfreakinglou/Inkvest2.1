import React from 'react';
import { Loader2 } from 'lucide-react';
import '../styles/LoadingSpinner.css';

const LoadingSpinner: React.FC = () => {
  return (
    <div className="loading-spinner">
      <Loader2 size={48} />
      <p>Loading...</p>
    </div>
  );
};

export default LoadingSpinner;