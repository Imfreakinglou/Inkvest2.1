import { useState } from 'react';
import { Comic } from '../types/Comic';

interface ValueResult {
  currentValue: number;
  estimatedValue: number;
}

interface ValuationService {
  getEstimatedValue: (comic: Partial<Comic>) => Promise<ValueResult>;
  isLoading: boolean;
}

// This would be replaced with actual API calls in a production app
export const useValuationService = (): ValuationService => {
  const [isLoading, setIsLoading] = useState(false);
  
  // Mock valuation logic - in a real app, this would call a pricing API
  const getEstimatedValue = async (comic: Partial<Comic>): Promise<ValueResult> => {
    setIsLoading(true);
    
    try {
      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Mock valuation logic based on title, issue, condition/grade
      let baseValue = 0;
      
      // Check some known valuable comics
      if (comic.title?.toLowerCase().includes('amazing spider-man') && comic.issueNumber === '300') {
        baseValue = 1800; // ASM 300 in NM
      } else if (comic.title?.toLowerCase().includes('new mutants') && comic.issueNumber === '98') {
        baseValue = 3500; // New Mutants 98 in NM
      } else if (comic.title?.toLowerCase().includes('batman adventures') && comic.issueNumber === '12') {
        baseValue = 1500; // Batman Adventures 12 in NM
      } else if (comic.title?.toLowerCase().includes('something is killing') && comic.issueNumber === '1') {
        baseValue = 650; // SIKTC #1 in NM
      } else if (comic.title?.toLowerCase().includes('invincible') && comic.issueNumber === '1') {
        baseValue = 3000; // Invincible #1 in NM
      } else if (comic.title?.toLowerCase().includes('ultimate fallout') && comic.issueNumber === '4') {
        baseValue = 1800; // Ultimate Fallout #4 in NM
      } else {
        // For other comics, generate a plausible value based on publication year
        if (comic.year) {
          if (comic.year < 1970) {
            baseValue = 100 + Math.floor(Math.random() * 200); // Older comics have higher base value
          } else if (comic.year < 1990) {
            baseValue = 50 + Math.floor(Math.random() * 100);
          } else if (comic.year < 2010) {
            baseValue = 20 + Math.floor(Math.random() * 40);
          } else {
            baseValue = 5 + Math.floor(Math.random() * 15); // Modern comics generally lower value
          }
        } else {
          baseValue = 10 + Math.floor(Math.random() * 20); // Default if no year
        }
      }
      
      // Adjust for condition/grade
      let conditionMultiplier = 1.0;
      if (comic.isSlabbed && comic.grade) {
        // Slabbed comics with grades
        if (comic.grade >= 9.8) conditionMultiplier = 1.0;
        else if (comic.grade >= 9.4) conditionMultiplier = 0.7;
        else if (comic.grade >= 9.0) conditionMultiplier = 0.5;
        else if (comic.grade >= 8.0) conditionMultiplier = 0.3;
        else conditionMultiplier = 0.2;
      } else if (comic.condition) {
        // Raw comics with condition
        switch (comic.condition) {
          case 'NM': conditionMultiplier = 1.0; break;
          case 'VF': conditionMultiplier = 0.7; break;
          case 'FN': conditionMultiplier = 0.4; break;
          case 'VG': conditionMultiplier = 0.25; break;
          case 'G': conditionMultiplier = 0.15; break;
          default: conditionMultiplier = 0.1;
        }
      }
      
      // Calculate current value
      const currentValue = Math.round(baseValue * conditionMultiplier);
      
      // Estimate future value (5-year projection)
      // For demo, add 20-40% growth for most comics
      let futureMultiplier = 1.2 + (Math.random() * 0.2);
      
      // Add extra premium for "hot" comics
      const isHotComic = comic.title?.toLowerCase().includes('something is killing') || 
                         comic.title?.toLowerCase().includes('ultimate fallout') ||
                         (comic.title?.toLowerCase().includes('amazing spider-man') && comic.issueNumber === '300');
      
      if (isHotComic) {
        futureMultiplier += 0.2; // Hot comics get extra boost
      }
      
      const estimatedValue = Math.round(currentValue * futureMultiplier);
      
      return {
        currentValue,
        estimatedValue
      };
    } catch (error) {
      console.error('Valuation error:', error);
      // Default fallback values
      return {
        currentValue: 0,
        estimatedValue: 0
      };
    } finally {
      setIsLoading(false);
    }
  };
  
  return {
    getEstimatedValue,
    isLoading
  };
};