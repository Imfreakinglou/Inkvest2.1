import { useState, useEffect, useCallback, useRef } from 'react';
import Webcam from 'react-webcam';
import { Comic } from '../types/Comic';

interface ScannerResult {
  isScanning: boolean;
  scanResult: Partial<Comic> | null;
  scanError: string | null;
  webcamRef: React.RefObject<Webcam>;
  startScanner: () => Promise<void>;
  stopScanner: () => void;
  captureImage: () => Promise<void>;
}

export const useScannerService = (): ScannerResult => {
  const [isScanning, setIsScanning] = useState(false);
  const [scanResult, setScanResult] = useState<Partial<Comic> | null>(null);
  const [scanError, setScanError] = useState<string | null>(null);
  const webcamRef = useRef<Webcam>(null);

  const videoConstraints = {
    width: { ideal: 1920 },
    height: { ideal: 1080 },
    facingMode: { ideal: 'environment' },
    aspectRatio: 3/2
  };

  const requestCameraPermission = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: videoConstraints 
      });
      return true;
    } catch (error) {
      console.error('Camera permission denied:', error);
      setScanError('Please grant camera access to scan comics');
      return false;
    }
  };

  const startScanner = async () => {
    setScanResult(null);
    setScanError(null);
    
    const hasPermission = await requestCameraPermission();
    if (hasPermission) {
      setIsScanning(true);
    }
  };

  const stopScanner = useCallback(() => {
    setIsScanning(false);
    if (webcamRef.current?.stream) {
      const tracks = webcamRef.current.stream.getTracks();
      tracks.forEach(track => track.stop());
    }
  }, []);

  const captureImage = async () => {
    if (!webcamRef.current) {
      setScanError('Camera not initialized');
      return;
    }

    try {
      const imageSrc = webcamRef.current.getScreenshot();
      if (!imageSrc) {
        throw new Error('Failed to capture image');
      }

      const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/scan-comic`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ image: imageSrc })
      });

      if (!response.ok) {
        throw new Error('Failed to analyze image');
      }

      const comicData = await response.json();
      setScanResult(comicData);
      setIsScanning(false);
    } catch (error) {
      console.error('Scan error:', error);
      setScanError(error instanceof Error ? error.message : 'Failed to scan comic');
      setIsScanning(false);
    }
  };

  useEffect(() => {
    return () => {
      stopScanner();
    };
  }, [stopScanner]);

  return {
    isScanning,
    scanResult,
    scanError,
    webcamRef,
    startScanner,
    stopScanner,
    captureImage
  };
};