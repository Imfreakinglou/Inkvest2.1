import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { usePortfolio } from '../contexts/PortfolioContext';
import { 
  ArrowLeftCircle, 
  Trash2, 
  Edit2, 
  TrendingUp, 
  TrendingDown,
  Calendar,
  DollarSign,
  Award,
  Info,
  AlertCircle 
} from 'lucide-react';
import ComicDetailForm from '../components/ComicDetailForm';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import LoadingSpinner from '../components/LoadingSpinner';
import '../styles/ComicDetailPage.css';

const ComicDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { getComicById, updateComic, removeComic, loading } = usePortfolio();
  const [isEditing, setIsEditing] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  
  const comic = getComicById(id || '');
  
  // Generate some historical value data for the chart
  const getHistoricalData = () => {
    if (!comic) return [];
    
    const currentDate = new Date();
    const purchaseDate = comic.purchaseDate ? new Date(comic.purchaseDate) : new Date(currentDate.getFullYear() - 1, 0, 1);
    
    // Get difference in months
    const diffMonths = (currentDate.getFullYear() - purchaseDate.getFullYear()) * 12 + 
                     (currentDate.getMonth() - purchaseDate.getMonth());
    
    // Generate monthly data points
    const points = Math.min(Math.max(diffMonths, 6), 24);
    const startValue = comic.purchasePrice || (comic.currentValue ? comic.currentValue * 0.7 : 10);
    const data = [];
    
    for (let i = 0; i <= points; i++) {
      const pointDate = new Date(purchaseDate);
      pointDate.setMonth(purchaseDate.getMonth() + i);
      
      // Calculate a value that trends toward the current value
      let pointValue;
      if (i === 0) {
        pointValue = startValue;
      } else if (i === points) {
        pointValue = comic.currentValue || startValue;
      } else {
        // Create a curve that gets steeper toward the end if value increased
        const progress = i / points;
        const factor = comic.currentValue && comic.currentValue > startValue 
          ? Math.pow(progress, 1.5) // Steeper curve for appreciation
          : progress;
        
        pointValue = startValue + factor * ((comic.currentValue || startValue) - startValue);
        
        // Add some randomness for a more natural chart
        const randomFactor = 0.05; // 5% max variation
        const randomness = 1 + (Math.random() * randomFactor * 2 - randomFactor);
        pointValue *= randomness;
      }
      
      data.push({
        date: pointDate.toISOString().substring(0, 7), // YYYY-MM format
        value: Math.round(pointValue * 100) / 100
      });
    }
    
    return data;
  };
  
  const handleBackClick = () => {
    navigate(-1);
  };
  
  const handleEditClick = () => {
    setIsEditing(true);
  };
  
  const handleCancelEdit = () => {
    setIsEditing(false);
  };
  
  const handleSaveEdit = async (updatedComic: any) => {
    try {
      await updateComic(id || '', updatedComic);
      setIsEditing(false);
    } catch (error) {
      console.error('Failed to update comic:', error);
    }
  };
  
  const handleDeleteClick = () => {
    setIsDeleting(true);
  };
  
  const handleConfirmDelete = async () => {
    try {
      await removeComic(id || '');
      navigate('/collection');
    } catch (error) {
      console.error('Failed to delete comic:', error);
      setIsDeleting(false);
    }
  };
  
  const handleCancelDelete = () => {
    setIsDeleting(false);
  };
  
  // Calculate gain/loss
  const calculateGain = () => {
    if (!comic || comic.purchasePrice === undefined || comic.currentValue === undefined) {
      return { amount: 0, percentage: 0 };
    }
    
    const amount = comic.currentValue - comic.purchasePrice;
    const percentage = comic.purchasePrice > 0 
      ? (amount / comic.purchasePrice) * 100 
      : 0;
    
    return {
      amount,
      percentage: Math.round(percentage * 10) / 10
    };
  };
  
  if (loading) {
    return <LoadingSpinner />;
  }
  
  if (!comic) {
    return (
      <div className="comic-detail-page">
        <div className="not-found">
          <AlertCircle size={48} />
          <h2>Comic Not Found</h2>
          <p>The comic you're looking for doesn't exist or has been removed</p>
          <button className="button secondary" onClick={handleBackClick}>
            Go Back
          </button>
        </div>
      </div>
    );
  }
  
  const gain = calculateGain();
  const isPositiveGain = gain.amount >= 0;
  const historicalData = getHistoricalData();
  
  // Get placeholder image based on publisher
  const getPlaceholderImage = () => {
    if (comic.publisher?.toLowerCase().includes('marvel')) {
      return 'https://images.pexels.com/photos/7800653/pexels-photo-7800653.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2';
    } else if (comic.publisher?.toLowerCase().includes('dc')) {
      return 'https://images.pexels.com/photos/8310426/pexels-photo-8310426.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2';
    } else if (comic.publisher?.toLowerCase().includes('image')) {
      return 'https://images.pexels.com/photos/7115878/pexels-photo-7115878.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2';
    } else {
      return 'https://images.pexels.com/photos/6474343/pexels-photo-6474343.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2';
    }
  };
  
  return (
    <div className="comic-detail-page">
      <div className="detail-header">
        <button className="back-button" onClick={handleBackClick}>
          <ArrowLeftCircle size={20} />
          <span>Back</span>
        </button>
        
        <div className="actions">
          {!isEditing && (
            <>
              <button className="edit-button" onClick={handleEditClick}>
                <Edit2 size={18} />
                <span>Edit</span>
              </button>
              <button className="delete-button" onClick={handleDeleteClick}>
                <Trash2 size={18} />
              </button>
            </>
          )}
        </div>
      </div>
      
      {isEditing ? (
        <div className="edit-container">
          <h2>Edit Comic Details</h2>
          <ComicDetailForm 
            initialData={comic} 
            onChange={(data) => {}}
          />
          <div className="edit-actions">
            <button className="button secondary" onClick={handleCancelEdit}>
              Cancel
            </button>
            <button 
              className="button primary" 
              onClick={() => handleSaveEdit(comic)}
            >
              Save Changes
            </button>
          </div>
        </div>
      ) : (
        <div className="comic-details">
          <div className="comic-image-container">
            <img 
              src={comic.coverImage || getPlaceholderImage()} 
              alt={`${comic.title} #${comic.issueNumber}`} 
              className="comic-image"
            />
            
            {comic.keyIssue && (
              <div className="key-issue-badge">
                <Award size={16} />
                <span>Key Issue</span>
              </div>
            )}
          </div>
          
          <div className="comic-info">
            <h1>{comic.title} #{comic.issueNumber}</h1>
            
            <div className="comic-metadata">
              {comic.publisher && <span className="publisher">{comic.publisher}</span>}
              {comic.year && <span className="year">{comic.year}</span>}
              
              <div className="grade-container">
                {comic.isSlabbed ? (
                  <span className="slabbed-grade">{comic.gradingCompany} {comic.grade}</span>
                ) : (
                  comic.condition && <span className="raw-condition">{comic.condition}</span>
                )}
              </div>
            </div>
            
            <div className="value-section">
              <div className="current-value">
                <h3>Current Value</h3>
                <div className="value">${comic.currentValue?.toFixed(2) || '0.00'}</div>
                
                <div className={`value-change ${isPositiveGain ? 'positive' : 'negative'}`}>
                  {isPositiveGain ? <TrendingUp size={18} /> : <TrendingDown size={18} />}
                  <span>
                    {isPositiveGain ? '+' : ''}${Math.abs(gain.amount).toFixed(2)} ({isPositiveGain ? '+' : ''}{gain.percentage}%)
                  </span>
                </div>
              </div>
              
              <div className="future-value">
                <h3>Projected Value (2030)</h3>
                <div className="value">${comic.estimatedValue?.toFixed(2) || '0.00'}</div>
              </div>
            </div>
            
            <div className="chart-container">
              <h3>Value History</h3>
              <ResponsiveContainer width="100%" height={200}>
                <LineChart data={historicalData}>
                  <XAxis 
                    dataKey="date" 
                    tick={{ fontSize: 12 }}
                    padding={{ left: 10, right: 10 }}
                  />
                  <YAxis 
                    width={50}
                    tick={{ fontSize: 12 }}
                    tickFormatter={(value) => `$${value}`}
                    domain={['dataMin', 'dataMax']}
                  />
                  <Tooltip 
                    formatter={(value) => [`$${value}`, 'Value']}
                    labelFormatter={(label) => {
                      const date = new Date(label);
                      return date.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
                    }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="value" 
                    stroke={isPositiveGain ? "#388E3C" : "#D32F2F"} 
                    strokeWidth={2} 
                    dot={false}
                    activeDot={{ r: 6 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
            
            <div className="comic-details-grid">
              <div className="detail-item">
                <div className="detail-icon">
                  <DollarSign size={18} />
                </div>
                <div className="detail-content">
                  <h4>Purchase Price</h4>
                  <p>${comic.purchasePrice?.toFixed(2) || 'Not set'}</p>
                </div>
              </div>
              
              <div className="detail-item">
                <div className="detail-icon">
                  <Calendar size={18} />
                </div>
                <div className="detail-content">
                  <h4>Purchase Date</h4>
                  <p>
                    {comic.purchaseDate ? new Date(comic.purchaseDate).toLocaleDateString() : 'Not set'}
                  </p>
                </div>
              </div>
              
              <div className="detail-item">
                <div className="detail-icon">
                  <Info size={18} />
                </div>
                <div className="detail-content">
                  <h4>Last Updated</h4>
                  <p>
                    {comic.lastUpdated ? new Date(comic.lastUpdated).toLocaleDateString() : 'Never'}
                  </p>
                </div>
              </div>
            </div>
            
            {comic.notes && (
              <div className="notes-section">
                <h3>Notes</h3>
                <p>{comic.notes}</p>
              </div>
            )}
          </div>
        </div>
      )}
      
      {isDeleting && (
        <div className="delete-confirmation-modal">
          <div className="modal-content">
            <h3>Delete Comic?</h3>
            <p>Are you sure you want to remove "{comic.title} #{comic.issueNumber}" from your collection? This action cannot be undone.</p>
            <div className="modal-actions">
              <button className="button secondary" onClick={handleCancelDelete}>
                Cancel
              </button>
              <button className="button primary danger" onClick={handleConfirmDelete}>
                <Trash2 size={18} />
                Delete Comic
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ComicDetailPage;