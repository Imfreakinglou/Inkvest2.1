import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Loader2, BookOpen, BarChart3, DollarSign, Scan } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import '../styles/OnboardingPage.css';

const OnboardingPage: React.FC = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [step, setStep] = useState(0);
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();
  
  const features = [
    {
      icon: <BookOpen size={48} />,
      title: 'Track Your Collection',
      description: 'Catalog your comics with detailed information and track their market value over time.'
    },
    {
      icon: <Scan size={48} />,
      title: 'Scan to Add',
      description: 'Simply scan your comic covers or barcodes to automatically identify and add them to your portfolio.'
    },
    {
      icon: <BarChart3 size={48} />,
      title: 'Investment Insights',
      description: 'Get personalized recommendations on when to buy, sell, or hold based on market trends.'
    },
    {
      icon: <DollarSign size={48} />,
      title: 'Value Projections',
      description: 'See potential future values based on historical data and upcoming media adaptations.'
    }
  ];
  
  const handleNextStep = () => {
    if (step < features.length) {
      setStep(step + 1);
    } else {
      handleCreateAccount();
    }
  };
  
  const handleCreateAccount = async () => {
    if (!email || !password) {
      return;
    }
    
    setLoading(true);
    
    try {
      // In a real app, this would register a new account
      // For the demo, we just log in
      await login(email, password);
    } catch (error) {
      console.error('Failed to create account:', error);
      setLoading(false);
    }
  };
  
  const renderStep = () => {
    if (step < features.length) {
      const feature = features[step];
      return (
        <div className="feature-slide">
          <div className="feature-icon">
            {feature.icon}
          </div>
          <h2>{feature.title}</h2>
          <p>{feature.description}</p>
        </div>
      );
    } else {
      return (
        <div className="signup-form">
          <h2>Create Your Account</h2>
          <p>Start tracking your comic portfolio today</p>
          
          <div className="form-group">
            <label htmlFor="name">Name</label>
            <input
              type="text"
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Your name"
              required
            />
          </div>
          
          <div className="form-group">
            <label htmlFor="email">Email</label>
            <input
              type="email"
              id="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="your@email.com"
              required
            />
          </div>
          
          <div className="form-group">
            <label htmlFor="password">Password</label>
            <input
              type="password"
              id="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Choose a secure password"
              required
            />
          </div>
        </div>
      );
    }
  };
  
  return (
    <div className="onboarding-page">
      <div className="onboarding-container">
        <div className="progress-dots">
          {features.concat({} as any).map((_, i) => (
            <div 
              key={i} 
              className={`progress-dot ${step === i ? 'active' : step > i ? 'completed' : ''}`}
              onClick={() => i <= step && setStep(i)}
            ></div>
          ))}
        </div>
        
        {renderStep()}
        
        <div className="onboarding-actions">
          {step > 0 && (
            <button 
              className="back-button"
              onClick={() => setStep(step - 1)}
              disabled={loading}
            >
              Back
            </button>
          )}
          
          <button 
            className="button primary next-button"
            onClick={handleNextStep}
            disabled={loading}
          >
            {loading ? (
              <>
                <Loader2 className="spinner" size={18} />
                Creating Account...
              </>
            ) : (
              step < features.length ? 'Next' : 'Create Account'
            )}
          </button>
        </div>
        
        <div className="login-link">
          Already have an account? <span onClick={() => navigate('/login')}>Log in</span>
        </div>
      </div>
    </div>
  );
};

export default OnboardingPage;