import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { Camera, X, Save, Loader2 } from 'lucide-react';
import { useScannerService } from '../hooks/useScannerService';
import ComicDetailForm from '../components/ComicDetailForm';
import { usePortfolio } from '../contexts/PortfolioContext';
import { Comic } from '../types/Comic';
import Webcam from 'react-webcam';
import '../styles/ScanPage.css';

const ScanPage: React.FC = () => {
  const [searchParams] = useSearchParams();
  const isManualMode = searchParams.get('manual') === 'true';
  const navigate = useNavigate();
  const { addComic } = usePortfolio();
  
  const { 
    startScanner, 
    stopScanner, 
    scanResult, 
    isScanning, 
    scanError,
    webcamRef,
    captureImage
  } = useScannerService();
  
  const [formData, setFormData] = useState<Partial<Comic>>({});
  const [isSaving, setIsSaving] = useState(false);
  const [showForm, setShowForm] = useState(isManualMode);
  
  useEffect(() => {
    if (!isManualMode && !scanResult) {
      startScanner();
    }
    
    return () => {
      stopScanner();
    };
  }, [isManualMode, startScanner, stopScanner, scanResult]);
  
  useEffect(() => {
    if (scanResult) {
      setFormData(scanResult);
      setShowForm(true);
    }
  }, [scanResult]);
  
  const handleFormChange = (updatedData: Partial<Comic>) => {
    setFormData({...formData, ...updatedData});
  };
  
  const handleCancel = () => {
    if (isManualMode) {
      navigate('/');
    } else {
      setShowForm(false);
      setFormData({});
      startScanner();
    }
  };
  
  const handleSave = async () => {
    setIsSaving(true);
    try {
      await addComic(formData as Comic);
      navigate('/');
    } catch (error) {
      console.error('Failed to save comic:', error);
    } finally {
      setIsSaving(false);
    }
  };

  const handleCapture = async () => {
    await captureImage();
  };
  
  return (
    <div className="scan-page">
      {showForm ? (
        <div className="comic-form-container">
          <div className="form-header">
            <h2>{scanResult ? 'Confirm Comic Details' : 'Add Comic Manually'}</h2>
            <button className="icon-button" onClick={handleCancel}>
              <X size={24} />
            </button>
          </div>
          
          <ComicDetailForm 
            initialData={formData} 
            onChange={handleFormChange} 
          />
          
          <div className="form-actions">
            <button className="button secondary" onClick={handleCancel}>
              Cancel
            </button>
            <button 
              className="button primary" 
              onClick={handleSave}
              disabled={isSaving}
            >
              {isSaving ? (
                <>
                  <Loader2 className="spinner" size={18} />
                  Saving...
                </>
              ) : (
                <>
                  <Save size={18} />
                  Save to Collection
                </>
              )}
            </button>
          </div>
        </div>
      ) : (
        <div className="scanner-container">
          <div className="scanner-header">
            <h2>Scan Comic</h2>
            <button className="icon-button" onClick={() => navigate('/')}>
              <X size={24} />
            </button>
          </div>
          
          <div className="scanner-view">
            {isScanning && (
              <Webcam
                ref={webcamRef}
                audio={false}
                screenshotFormat="image/jpeg"
                videoConstraints={{
                  width: { ideal: 1920 },
                  height: { ideal: 1080 },
                  facingMode: { ideal: 'environment' },
                  aspectRatio: 3/2
                }}
                className="webcam-preview"
              />
            )}
            {isScanning && (
              <div className="scanner-overlay">
                <div className="scanner-guide">
                  <Camera size={32} />
                  <p>Position comic cover within frame</p>
                  <button 
                    className="capture-button"
                    onClick={handleCapture}
                  >
                    Capture
                  </button>
                </div>
              </div>
            )}
            {scanError && (
              <div className="scan-error">
                <p>{scanError}</p>
                <button className="button secondary" onClick={() => startScanner()}>
                  Try Again
                </button>
              </div>
            )}
          </div>
          
          <div className="scanner-actions">
            <button 
              className="button secondary"
              onClick={() => setShowForm(true)}
            >
              Enter Manually
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default ScanPage;