import React, { useState } from 'react';
import { usePortfolio } from '../contexts/PortfolioContext';
import { 
  ArrowRight, 
  TrendingUp, 
  DollarSign, 
  ShoppingCart,
  AlertTriangle, 
  Info,
  Filter 
} from 'lucide-react';
import '../styles/RecommendationsPage.css';

enum RecommendationType {
  Sell = 'sell',
  Hold = 'hold',
  Buy = 'buy'
}

interface Recommendation {
  id: string;
  title: string;
  issueNumber: string;
  publisher?: string;
  currentValue: number;
  projectedValue: number;
  growthPercentage: number;
  type: RecommendationType;
  reason: string;
  mediaRelated?: boolean;
}

// Sample recommendations data
const sampleRecommendations: Recommendation[] = [
  {
    id: 'rec1',
    title: 'Ultimate Fallout',
    issueNumber: '4',
    publisher: 'Marvel',
    currentValue: 1800,
    projectedValue: 2500,
    growthPercentage: 38.9,
    type: RecommendationType.Hold,
    reason: 'Key first appearance with ongoing media presence',
    mediaRelated: true
  },
  {
    id: 'rec2',
    title: 'Something is Killing the Children',
    issueNumber: '1',
    publisher: 'Boom! Studios',
    currentValue: 650,
    projectedValue: 950,
    growthPercentage: 46.2,
    type: RecommendationType.Buy,
    reason: 'Netflix adaptation announced, undervalued compared to potential',
    mediaRelated: true
  },
  {
    id: 'rec3',
    title: 'New Mutants',
    issueNumber: '98',
    publisher: 'Marvel',
    currentValue: 3500,
    projectedValue: 4200,
    growthPercentage: 20,
    type: RecommendationType.Hold,
    reason: 'Deadpool 3 trailer released, expect continued interest'
  },
  {
    id: 'rec4',
    title: 'Turok: Dinosaur Hunter',
    issueNumber: '1',
    publisher: 'Valiant',
    currentValue: 5,
    projectedValue: 5,
    growthPercentage: 0,
    type: RecommendationType.Sell,
    reason: 'Overprinted 90s comic with no growth prospects'
  },
  {
    id: 'rec5',
    title: 'Batman',
    issueNumber: '500',
    publisher: 'DC',
    currentValue: 5,
    projectedValue: 5,
    growthPercentage: 0,
    type: RecommendationType.Sell,
    reason: 'Common 90s issue with flat market value'
  },
  {
    id: 'rec6',
    title: 'Invincible',
    issueNumber: '1',
    publisher: 'Image',
    currentValue: 3000,
    projectedValue: 3600,
    growthPercentage: 20,
    type: RecommendationType.Buy,
    reason: 'Prime series continuing with strong buzz',
    mediaRelated: true
  },
  {
    id: 'rec7',
    title: 'God Country',
    issueNumber: '1',
    publisher: 'Image',
    currentValue: 10,
    projectedValue: 20,
    growthPercentage: 100,
    type: RecommendationType.Buy,
    reason: 'Optioned for film adaptation, cult following'
  },
  {
    id: 'rec8',
    title: 'Edge of Spider-Verse',
    issueNumber: '2',
    publisher: 'Marvel',
    currentValue: 700,
    projectedValue: 850,
    growthPercentage: 21.4,
    type: RecommendationType.Hold,
    reason: 'Spider-Gwen remains popular with more animated films planned',
    mediaRelated: true
  }
];

const RecommendationsPage: React.FC = () => {
  const { portfolio } = usePortfolio();
  const [activeFilter, setActiveFilter] = useState<RecommendationType | 'all'>('all');
  const [showFilterMenu, setShowFilterMenu] = useState(false);
  
  const filteredRecommendations = activeFilter === 'all' 
    ? sampleRecommendations 
    : sampleRecommendations.filter(rec => rec.type === activeFilter);
  
  const handleFilterClick = (filter: RecommendationType | 'all') => {
    setActiveFilter(filter);
    setShowFilterMenu(false);
  };
  
  return (
    <div className="recommendations-page">
      <div className="page-header">
        <h1>Investment Insights</h1>
        
        <button 
          className="filter-toggle"
          onClick={() => setShowFilterMenu(!showFilterMenu)}
        >
          <Filter size={18} />
          <span>Filter</span>
        </button>
      </div>
      
      {showFilterMenu && (
        <div className="filter-options">
          <button 
            className={activeFilter === 'all' ? 'active' : ''}
            onClick={() => handleFilterClick('all')}
          >
            All Recommendations
          </button>
          <button 
            className={activeFilter === RecommendationType.Buy ? 'active' : ''}
            onClick={() => handleFilterClick(RecommendationType.Buy)}
          >
            Buy
          </button>
          <button 
            className={activeFilter === RecommendationType.Hold ? 'active' : ''}
            onClick={() => handleFilterClick(RecommendationType.Hold)}
          >
            Hold
          </button>
          <button 
            className={activeFilter === RecommendationType.Sell ? 'active' : ''}
            onClick={() => handleFilterClick(RecommendationType.Sell)}
          >
            Sell
          </button>
        </div>
      )}
      
      <div className="insight-categories">
        <div 
          className={`category-pill ${activeFilter === 'all' ? 'active' : ''}`}
          onClick={() => handleFilterClick('all')}
        >
          All
        </div>
        <div 
          className={`category-pill buy ${activeFilter === RecommendationType.Buy ? 'active' : ''}`}
          onClick={() => handleFilterClick(RecommendationType.Buy)}
        >
          <ShoppingCart size={16} />
          Buy
        </div>
        <div 
          className={`category-pill hold ${activeFilter === RecommendationType.Hold ? 'active' : ''}`}
          onClick={() => handleFilterClick(RecommendationType.Hold)}
        >
          <TrendingUp size={16} />
          Hold
        </div>
        <div 
          className={`category-pill sell ${activeFilter === RecommendationType.Sell ? 'active' : ''}`}
          onClick={() => handleFilterClick(RecommendationType.Sell)}
        >
          <DollarSign size={16} />
          Sell
        </div>
      </div>
      
      <div className="portfolio-insight">
        <h2>Portfolio Health</h2>
        <div className="portfolio-metrics">
          <div className="metric">
            <span className="metric-label">Portfolio Diversification</span>
            <div className="metric-value">
              <div className="diversity-bar-container">
                <div 
                  className="diversity-bar" 
                  style={{
                    width: `${Math.min(portfolio.publisherBreakdown.length * 20, 85)}%`,
                    backgroundColor: portfolio.publisherBreakdown.length < 3 ? '#D32F2F' : '#388E3C'
                  }}
                ></div>
              </div>
              <span className="diversity-label">
                {portfolio.publisherBreakdown.length <= 1 
                  ? 'Poor' 
                  : portfolio.publisherBreakdown.length <= 3 
                    ? 'Fair' 
                    : 'Good'}
              </span>
            </div>
          </div>
          
          <div className="metric">
            <span className="metric-label">Growth Potential</span>
            <div className="metric-value">
              <div className="percentage">
                {(((portfolio.potentialValue / portfolio.totalValue) - 1) * 100).toFixed(1)}%
              </div>
              <span className="time-horizon">by 2030</span>
            </div>
          </div>
        </div>
      </div>
      
      <div className="recommendations-grid">
        {filteredRecommendations.map(rec => (
          <div 
            key={rec.id} 
            className={`recommendation-card ${rec.type}`}
          >
            <div className="rec-header">
              <div className="rec-type">
                {rec.type === RecommendationType.Buy && <ShoppingCart size={18} />}
                {rec.type === RecommendationType.Hold && <TrendingUp size={18} />}
                {rec.type === RecommendationType.Sell && <DollarSign size={18} />}
                <span>{rec.type.toUpperCase()}</span>
              </div>
              
              {rec.mediaRelated && (
                <div className="media-badge">
                  <Info size={16} />
                  <span>Media Tie-in</span>
                </div>
              )}
            </div>
            
            <h3 className="rec-title">
              {rec.title} #{rec.issueNumber}
            </h3>
            
            {rec.publisher && (
              <div className="rec-publisher">{rec.publisher}</div>
            )}
            
            <div className="value-projection">
              <div className="current-value">
                <span className="label">Current</span>
                <span className="value">${rec.currentValue}</span>
              </div>
              
              <div className="projection-arrow">
                <ArrowRight />
              </div>
              
              <div className="projected-value">
                <span className="label">Projected</span>
                <span className="value">${rec.projectedValue}</span>
                <span className="growth">+{rec.growthPercentage}%</span>
              </div>
            </div>
            
            <p className="rec-reason">{rec.reason}</p>
          </div>
        ))}
      </div>
      
      <div className="recommendation-disclaimer">
        <AlertTriangle size={18} />
        <p>These recommendations are based on market trends and speculation. Comic values can fluctuate significantly. Always do your own research before making investment decisions.</p>
      </div>
    </div>
  );
};

export default RecommendationsPage;