import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { usePortfolio } from '../contexts/PortfolioContext';
import PortfolioSummary from '../components/PortfolioSummary';
import RecentComics from '../components/RecentComics';
import MarketTrends from '../components/MarketTrends';
import ActionButton from '../components/ActionButton';
import { ScanIcon as ScannerIcon, PlusCircleIcon } from 'lucide-react';
import LoadingSpinner from '../components/LoadingSpinner';
import '../styles/HomePage.css';

const HomePage: React.FC = () => {
  const navigate = useNavigate();
  const { portfolio, loading, refreshPortfolio } = usePortfolio();
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    // Refresh portfolio data when the component mounts
    refreshPortfolio();
  }, [refreshPortfolio]);

  const handleRefresh = async () => {
    setRefreshing(true);
    await refreshPortfolio();
    setRefreshing(false);
  };

  const handleScanComic = () => {
    navigate('/scan');
  };

  const handleAddManually = () => {
    navigate('/scan?manual=true');
  };

  if (loading && !refreshing) {
    return <LoadingSpinner />;
  }

  return (
    <div className="home-page">
      <header className="page-header">
        <h1>Comic Portfolio</h1>
        <div className="header-actions">
          <button 
            className="refresh-button" 
            onClick={handleRefresh}
            disabled={refreshing}
          >
            {refreshing ? 'Refreshing...' : 'Refresh'}
          </button>
        </div>
      </header>

      <PortfolioSummary portfolio={portfolio} />

      <section className="quick-actions">
        <ActionButton 
          icon={<ScannerIcon />} 
          label="Scan Comic" 
          onClick={handleScanComic} 
          primary
        />
        <ActionButton 
          icon={<PlusCircleIcon />} 
          label="Add Manually" 
          onClick={handleAddManually}
        />
      </section>

      <section className="recent-additions">
        <h2>Recent Additions</h2>
        <RecentComics limit={3} />
      </section>

      <section className="market-trends">
        <h2>Market Trends</h2>
        <MarketTrends />
      </section>

      <section className="quick-insights">
        <div className="insight-card">
          <h3>Top Performer</h3>
          {portfolio.topPerformer ? (
            <>
              <p className="comic-title">{portfolio.topPerformer.title}</p>
              <p className="comic-gain">+{portfolio.topPerformer.gainPercentage}%</p>
            </>
          ) : (
            <p>Add comics to see your top performer</p>
          )}
        </div>
        <div className="insight-card">
          <h3>Hot This Week</h3>
          <p className="comic-title">Something is Killing the Children #1</p>
          <p className="hot-reason">Netflix adaptation announced</p>
        </div>
      </section>
    </div>
  );
};

export default HomePage;