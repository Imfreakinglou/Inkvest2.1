import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { Loader2 } from 'lucide-react';
import '../styles/LoginPage.css';

const LoginPage: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (!email || !password) {
      setError('Please enter both email and password');
      return;
    }
    
    setIsLoggingIn(true);
    
    try {
      await login(email, password);
      // Successful login will redirect via the AuthContext
    } catch (err) {
      setError('Invalid credentials. Please try again.');
      setIsLoggingIn(false);
    }
  };
  
  const handleDemoLogin = async () => {
    setIsLoggingIn(true);
    try {
      await login('demo@example.com', 'demopassword');
    } catch (err) {
      setError('Demo login failed. Please try again.');
      setIsLoggingIn(false);
    }
  };
  
  return (
    <div className="login-page">
      <div className="login-container">
        <div className="login-header">
          <h1>InkVest</h1>
          <p>Track your comic investment portfolio</p>
        </div>
        
        <form className="login-form" onSubmit={handleSubmit}>
          {error && <div className="login-error">{error}</div>}
          
          <div className="form-group">
            <label htmlFor="email">Email</label>
            <input
              type="email"
              id="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="your@email.com"
              disabled={isLoggingIn}
            />
          </div>
          
          <div className="form-group">
            <label htmlFor="password">Password</label>
            <input
              type="password"
              id="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="•••••••••••"
              disabled={isLoggingIn}
            />
          </div>
          
          <button 
            type="submit" 
            className="button primary login-button"
            disabled={isLoggingIn}
          >
            {isLoggingIn ? (
              <>
                <Loader2 className="spinner" size={18} />
                Logging in...
              </>
            ) : (
              'Log In'
            )}
          </button>
          
          <button 
            type="button" 
            className="button secondary demo-button"
            onClick={handleDemoLogin}
            disabled={isLoggingIn}
          >
            Try Demo
          </button>
        </form>
        
        <div className="login-footer">
          <p>Don't have an account? <span onClick={() => navigate('/onboarding')}>Sign up</span></p>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;