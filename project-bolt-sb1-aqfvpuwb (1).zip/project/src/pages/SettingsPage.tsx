import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { usePortfolio } from '../contexts/PortfolioContext';
import { Save, Trash2, LogOut, Loader2, AlertTriangle } from 'lucide-react';
import '../styles/SettingsPage.css';

const SettingsPage: React.FC = () => {
  const { user, logout } = useAuth();
  const { refreshPortfolio } = usePortfolio();
  
  const [displayName, setDisplayName] = useState(user?.displayName || '');
  const [email, setEmail] = useState(user?.email || '');
  const [isSaving, setIsSaving] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  
  // Settings options
  const [notifyPriceAlerts, setNotifyPriceAlerts] = useState(true);
  const [notifyMediaAnnouncements, setNotifyMediaAnnouncements] = useState(true);
  const [darkMode, setDarkMode] = useState(false);
  const [currency, setCurrency] = useState('USD');
  
  const handleSaveProfile = async () => {
    setIsSaving(true);
    
    try {
      // In a real app, this would update the user profile
      // For the demo, we just simulate a delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Simulate success
      alert('Profile updated successfully');
      
      setIsSaving(false);
    } catch (error) {
      console.error('Failed to update profile:', error);
      setIsSaving(false);
    }
  };
  
  const handleDeleteAccount = async () => {
    // In a real app, this would delete the user account
    // For the demo, we just log out
    logout();
  };
  
  const handleExportData = () => {
    // Create a JSON blob of the portfolio data
    const portfolioData = localStorage.getItem('comics') || '[]';
    const blob = new Blob([portfolioData], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    
    // Create temporary link element and trigger download
    const link = document.createElement('a');
    link.href = url;
    link.download = 'comic-portfolio-export.json';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    // Clean up the URL
    URL.revokeObjectURL(url);
  };
  
  const handleClearData = async () => {
    try {
      localStorage.removeItem('comics');
      await refreshPortfolio();
      
      alert('Portfolio data cleared successfully');
    } catch (error) {
      console.error('Failed to clear data:', error);
    }
  };
  
  return (
    <div className="settings-page">
      <h1>Settings</h1>
      
      <div className="settings-section">
        <h2>Profile</h2>
        <div className="settings-card">
          <div className="form-group">
            <label htmlFor="displayName">Display Name</label>
            <input
              type="text"
              id="displayName"
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
            />
          </div>
          
          <div className="form-group">
            <label htmlFor="email">Email</label>
            <input
              type="email"
              id="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>
          
          <div className="form-actions">
            <button 
              className="button primary"
              onClick={handleSaveProfile}
              disabled={isSaving}
            >
              {isSaving ? (
                <>
                  <Loader2 className="spinner" size={18} />
                  Saving...
                </>
              ) : (
                <>
                  <Save size={18} />
                  Save Profile
                </>
              )}
            </button>
          </div>
        </div>
      </div>
      
      <div className="settings-section">
        <h2>Notifications</h2>
        <div className="settings-card">
          <div className="setting-toggle">
            <label htmlFor="priceAlerts">Price Change Alerts</label>
            <div className="toggle-switch">
              <input
                type="checkbox"
                id="priceAlerts"
                checked={notifyPriceAlerts}
                onChange={(e) => setNotifyPriceAlerts(e.target.checked)}
              />
              <span className="toggle-slider"></span>
            </div>
          </div>
          
          <div className="setting-toggle">
            <label htmlFor="mediaAlerts">Media Announcements</label>
            <div className="toggle-switch">
              <input
                type="checkbox"
                id="mediaAlerts"
                checked={notifyMediaAnnouncements}
                onChange={(e) => setNotifyMediaAnnouncements(e.target.checked)}
              />
              <span className="toggle-slider"></span>
            </div>
          </div>
        </div>
      </div>
      
      <div className="settings-section">
        <h2>Preferences</h2>
        <div className="settings-card">
          <div className="setting-toggle">
            <label htmlFor="darkMode">Dark Mode</label>
            <div className="toggle-switch">
              <input
                type="checkbox"
                id="darkMode"
                checked={darkMode}
                onChange={(e) => setDarkMode(e.target.checked)}
              />
              <span className="toggle-slider"></span>
            </div>
          </div>
          
          <div className="form-group">
            <label htmlFor="currency">Currency</label>
            <select 
              id="currency"
              value={currency}
              onChange={(e) => setCurrency(e.target.value)}
            >
              <option value="USD">USD ($)</option>
              <option value="EUR">EUR (€)</option>
              <option value="GBP">GBP (£)</option>
              <option value="CAD">CAD ($)</option>
              <option value="AUD">AUD ($)</option>
            </select>
          </div>
        </div>
      </div>
      
      <div className="settings-section">
        <h2>Data Management</h2>
        <div className="settings-card">
          <div className="data-actions">
            <button 
              className="button secondary"
              onClick={handleExportData}
            >
              Export Portfolio Data
            </button>
            
            <button 
              className="button tertiary"
              onClick={handleClearData}
            >
              Clear Portfolio Data
            </button>
          </div>
        </div>
      </div>
      
      <div className="settings-section">
        <h2>Account</h2>
        <div className="settings-card danger-zone">
          <div className="danger-header">
            <AlertTriangle size={20} />
            <h3>Danger Zone</h3>
          </div>
          
          <p>Once deleted, your account and all associated data cannot be recovered.</p>
          
          {!showDeleteConfirm ? (
            <button 
              className="button danger"
              onClick={() => setShowDeleteConfirm(true)}
            >
              <Trash2 size={18} />
              Delete Account
            </button>
          ) : (
            <div className="delete-confirmation">
              <p>Are you sure you want to delete your account?</p>
              <div className="confirmation-actions">
                <button 
                  className="button tertiary"
                  onClick={() => setShowDeleteConfirm(false)}
                >
                  Cancel
                </button>
                
                <button 
                  className="button danger"
                  onClick={handleDeleteAccount}
                >
                  Yes, Delete My Account
                </button>
              </div>
            </div>
          )}
        </div>
        
        <div className="logout-section">
          <button 
            className="button tertiary logout-button"
            onClick={logout}
          >
            <LogOut size={18} />
            Log Out
          </button>
        </div>
      </div>
    </div>
  );
};

export default SettingsPage;