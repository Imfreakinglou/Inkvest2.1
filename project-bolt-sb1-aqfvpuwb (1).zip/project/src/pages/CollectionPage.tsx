import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { usePortfolio } from '../contexts/PortfolioContext';
import ComicCard from '../components/ComicCard';
import { Search, Filter, SortAsc, SortDesc, Trash2 } from 'lucide-react';
import LoadingSpinner from '../components/LoadingSpinner';
import '../styles/CollectionPage.css';

enum SortField {
  Value = 'value',
  Title = 'title',
  Date = 'date',
  Gain = 'gain'
}

const CollectionPage: React.FC = () => {
  const navigate = useNavigate();
  const { comics, loading, removeComic } = usePortfolio();
  const [searchTerm, setSearchTerm] = useState('');
  const [sortField, setSortField] = useState<SortField>(SortField.Value);
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');
  const [filteredComics, setFilteredComics] = useState(comics);
  const [filterPublisher, setFilterPublisher] = useState<string>('all');
  const [showFilterMenu, setShowFilterMenu] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<string | null>(null);
  
  // Get unique publishers for filter
  const publishers = React.useMemo(() => {
    const unique = Array.from(new Set(comics.map(comic => comic.publisher || 'Unknown')));
    return ['all', ...unique];
  }, [comics]);
  
  // Update filtered comics when data changes
  useEffect(() => {
    let filtered = [...comics];
    
    // Apply search filter
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      filtered = filtered.filter(comic => 
        comic.title?.toLowerCase().includes(term) || 
        comic.issueNumber?.toLowerCase().includes(term) ||
        comic.publisher?.toLowerCase().includes(term) ||
        comic.notes?.toLowerCase().includes(term)
      );
    }
    
    // Apply publisher filter
    if (filterPublisher !== 'all') {
      filtered = filtered.filter(comic => 
        (comic.publisher || 'Unknown') === filterPublisher
      );
    }
    
    // Apply sorting
    filtered.sort((a, b) => {
      let compareA: string | number = '';
      let compareB: string | number = '';
      
      switch (sortField) {
        case SortField.Value:
          compareA = a.currentValue || 0;
          compareB = b.currentValue || 0;
          break;
        case SortField.Title:
          compareA = `${a.title || ''} ${a.issueNumber || ''}`;
          compareB = `${b.title || ''} ${b.issueNumber || ''}`;
          break;
        case SortField.Date:
          compareA = a.addedDate || '';
          compareB = b.addedDate || '';
          break;
        case SortField.Gain:
          const gainA = (a.currentValue || 0) - (a.purchasePrice || 0);
          const gainB = (b.currentValue || 0) - (b.purchasePrice || 0);
          compareA = gainA;
          compareB = gainB;
          break;
      }
      
      if (sortDirection === 'asc') {
        return compareA > compareB ? 1 : -1;
      } else {
        return compareA < compareB ? 1 : -1;
      }
    });
    
    setFilteredComics(filtered);
  }, [comics, searchTerm, sortField, sortDirection, filterPublisher]);
  
  const toggleSortDirection = () => {
    setSortDirection(prev => prev === 'asc' ? 'desc' : 'asc');
  };
  
  const handleComicClick = (id: string) => {
    navigate(`/comic/${id}`);
  };

  const handleDeleteClick = (id: string, event: React.MouseEvent) => {
    event.stopPropagation();
    setShowDeleteConfirm(id);
  };

  const handleConfirmDelete = async (id: string) => {
    try {
      await removeComic(id);
      setShowDeleteConfirm(null);
    } catch (error) {
      console.error('Failed to delete comic:', error);
    }
  };
  
  if (loading) {
    return <LoadingSpinner />;
  }
  
  return (
    <div className="collection-page">
      <header className="page-header">
        <h1>Your Collection</h1>
        <div className="comic-count">
          {filteredComics.length} {filteredComics.length === 1 ? 'comic' : 'comics'}
        </div>
      </header>
      
      <div className="collection-tools">
        <div className="search-container">
          <Search size={18} />
          <input
            type="text"
            placeholder="Search your collection..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        
        <div className="filter-sort-controls">
          <button 
            className="filter-button"
            onClick={() => setShowFilterMenu(!showFilterMenu)}
          >
            <Filter size={18} />
            <span>Filter</span>
          </button>
          
          <div className="sort-controls">
            <select
              value={sortField}
              onChange={(e) => setSortField(e.target.value as SortField)}
            >
              <option value={SortField.Value}>Value</option>
              <option value={SortField.Title}>Title</option>
              <option value={SortField.Date}>Date Added</option>
              <option value={SortField.Gain}>Gain/Loss</option>
            </select>
            
            <button 
              className="sort-direction-button"
              onClick={toggleSortDirection}
            >
              {sortDirection === 'asc' ? <SortAsc size={18} /> : <SortDesc size={18} />}
            </button>
          </div>
        </div>
        
        {showFilterMenu && (
          <div className="filter-dropdown">
            <div className="filter-section">
              <h3>Publisher</h3>
              <div className="publisher-filters">
                {publishers.map(publisher => (
                  <button
                    key={publisher}
                    className={`publisher-filter ${filterPublisher === publisher ? 'active' : ''}`}
                    onClick={() => setFilterPublisher(publisher)}
                  >
                    {publisher === 'all' ? 'All Publishers' : publisher}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
      
      {filteredComics.length === 0 ? (
        <div className="no-comics">
          <p>{searchTerm || filterPublisher !== 'all' ? 'No comics match your search or filters' : 'Your collection is empty'}</p>
          <button 
            className="button primary"
            onClick={() => navigate('/scan')}
          >
            Add Your First Comic
          </button>
        </div>
      ) : (
        <div className="comics-grid">
          {filteredComics.map(comic => (
            <div key={comic.id} className="comic-card-wrapper">
              <ComicCard 
                comic={comic} 
                onClick={() => handleComicClick(comic.id)}
              />
              <button
                className="delete-button"
                onClick={(e) => handleDeleteClick(comic.id, e)}
              >
                <Trash2 size={18} />
              </button>
              {showDeleteConfirm === comic.id && (
                <div className="delete-confirmation">
                  <p>Delete this comic?</p>
                  <div className="delete-actions">
                    <button 
                      className="cancel-button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setShowDeleteConfirm(null);
                      }}
                    >
                      Cancel
                    </button>
                    <button 
                      className="confirm-button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleConfirmDelete(comic.id);
                      }}
                    >
                      Delete
                    </button>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default CollectionPage;