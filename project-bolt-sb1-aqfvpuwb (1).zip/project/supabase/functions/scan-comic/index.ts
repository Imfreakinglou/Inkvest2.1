import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import OpenAI from "npm:openai@4.28.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
};

const openai = new OpenAI({
  apiKey: Deno.env.get("OPENAI_API_KEY")
});

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { image } = await req.json();

    if (!image) {
      return new Response(
        JSON.stringify({ error: "Image data is required" }),
        { 
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" }
        }
      );
    }

    // Extract base64 data from data URL
    const base64Image = image.split(',')[1];

    const response = await openai.chat.completions.create({
      model: "gpt-4-vision-preview",
      messages: [
        {
          role: "user",
          content: [
            {
              type: "text",
              text: "This is a comic book cover. Please extract the following information in JSON format with these exact keys: title (string), issueNumber (string), year (number, optional), publisher (string, optional), keyIssue (boolean), notes (string, optional). Include any significant details like first appearances or important events in the notes field."
            },
            {
              type: "image_url",
              image_url: {
                url: `data:image/jpeg;base64,${base64Image}`
              }
            }
          ]
        }
      ],
      max_tokens: 500,
      temperature: 0.1 // Lower temperature for more consistent JSON formatting
    });

    const content = response.choices[0].message.content;
    let parsedContent;

    try {
      // Try to parse the content as JSON
      parsedContent = JSON.parse(content);
      
      // Ensure the response matches our Comic type structure
      const formattedResponse = {
        title: parsedContent.title || "",
        issueNumber: parsedContent.issueNumber || "",
        year: parsedContent.year || undefined,
        publisher: parsedContent.publisher || undefined,
        keyIssue: parsedContent.keyIssue || false,
        notes: parsedContent.notes || undefined,
        addedDate: new Date().toISOString()
      };

      return new Response(
        JSON.stringify(formattedResponse),
        { 
          headers: { ...corsHeaders, "Content-Type": "application/json" }
        }
      );
    } catch (e) {
      console.error('Failed to parse OpenAI response:', content);
      return new Response(
        JSON.stringify({ error: "Failed to parse comic information" }),
        { 
          status: 422,
          headers: { ...corsHeaders, "Content-Type": "application/json" }
        }
      );
    }
  } catch (error) {
    console.error('Error processing request:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { 
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" }
      }
    );
  }
});